-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: k11a304.p.ssafy.io    Database: shortgong
-- ------------------------------------------------------
-- Server version	9.1.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `summary`
--

DROP TABLE IF EXISTS `summary`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `summary` (
  `summary_id` bigint NOT NULL AUTO_INCREMENT,
  `created_at` datetime NOT NULL,
  `modified_at` datetime DEFAULT NULL,
  `clova_voice` varchar(64) DEFAULT NULL,
  `folder_name` varchar(64) DEFAULT NULL,
  `summary_title` varchar(64) DEFAULT NULL,
  `upload_content_id` bigint NOT NULL,
  `writer_id` bigint NOT NULL,
  PRIMARY KEY (`summary_id`),
  UNIQUE KEY `UKka9yowspq53l6sq2bwedkimgs` (`upload_content_id`),
  KEY `FKlo35mi8t83trhbu4wk1em120l` (`writer_id`),
  CONSTRAINT `FKlo35mi8t83trhbu4wk1em120l` FOREIGN KEY (`writer_id`) REFERENCES `user` (`user_id`),
  CONSTRAINT `FKw8t5qkxofri8dttg4wb8pc9w` FOREIGN KEY (`upload_content_id`) REFERENCES `upload_content` (`upload_content_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `summary`
--

LOCK TABLES `summary` WRITE;
/*!40000 ALTER TABLE `summary` DISABLE KEYS */;
INSERT INTO `summary` VALUES (1,'2024-11-19 00:19:44','2024-11-19 00:21:15',NULL,'672c8df8-d51d-4f1d-9a8d-7ee258f0bbba','일본 경제발전 원동력 평가',1,1),(2,'2024-11-19 00:30:23','2024-11-19 00:30:23',NULL,'965a0216-9434-40af-b535-45225e97b130','한일경제관계의이해 (10.12)',2,1),(3,'2024-11-19 00:42:32','2024-11-19 00:43:40',NULL,'bc60deae-5dcd-4d5d-a3ce-a8114cc4abf3','한일 경제 관계의 현황 이슈2 : 양국 격차 축소 추이 및 전망',3,1),(4,'2024-11-19 01:07:08','2024-11-19 01:07:52',NULL,'4447f1ec-9a99-4372-90ff-abb3fe10319c','일제의 식민정책과 저항',4,1),(5,'2024-11-19 01:32:52','2024-11-19 01:33:34',NULL,'a268d2bc-0ec6-4b85-9094-6d6f3a08983a','한일 양국 격차 전망',5,1),(6,'2024-11-19 01:45:27','2024-11-19 01:46:30',NULL,'dac19ccd-167f-4c9b-b74a-4637d4e2fadd','한일 양국 격차 추이',6,1),(7,'2024-11-19 08:42:28','2024-11-19 08:43:34',NULL,'fd69156e-4e3b-4e93-80d0-705ecc015252','정처기 7장',7,1),(8,'2024-11-19 08:51:46','2024-11-19 08:52:33',NULL,'49b54882-af2c-4868-b21a-225a718db566','정보처리기사 1장',8,2),(9,'2024-11-19 09:10:51','2024-11-19 09:11:40',NULL,'36bac2e4-c8f7-4f5b-b5d6-293aa462939f','데이터베이스 정규화',9,1),(10,'2024-11-19 01:15:21','2024-11-19 01:16:16',NULL,'96b8371b-8ee6-434a-8971-1ee463adaf21','데이터베이스 뷰(View)',10,2),(11,'2024-11-19 09:18:47','2024-11-19 09:19:37',NULL,'17c4990a-3022-46ff-b779-040312b73048','정처기1장 요약',11,2);
/*!40000 ALTER TABLE `summary` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-11-19 11:46:45
